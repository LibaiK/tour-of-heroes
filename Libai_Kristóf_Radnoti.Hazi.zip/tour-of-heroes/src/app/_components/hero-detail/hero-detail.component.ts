import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HeroService } from 'src/app/_services/hero.service';
import { MessageService } from 'src/app/_services/message.service';
import { Hero } from '../../_models/hero';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Validators } from '@angular/forms';
import { HEROES } from 'src/app/fake-db';


@Component({
  selector: 'app-hero-detail',
  templateUrl: './hero-detail.component.html',
  styleUrls: ['./hero-detail.component.less'],
})
export class HeroDetailComponent implements OnInit {


  heroprofileform = new FormGroup({
    heroname :  new FormControl('',Validators.required),
    heroage :new FormControl('',Validators.required),
    superpower : new FormControl('',Validators.required),
    })
  hero: Hero | undefined;

  constructor(
    private route: ActivatedRoute,
    private _heroService: HeroService,
    private _messageService: MessageService,
    private fb: FormBuilder
  ) {}
  hero2:Hero = {
    id:10,
    name:"GoldFish",
    age:42,
    superpower:'Laser destoyer'
  }

  ngOnInit(): void {
    this.getHeroByID();

    this._messageService.add(`A ${this.hero?.name} nevű hős betöltve`);
  }

  getHeroByID(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this._heroService
      .getHero(id)
      .subscribe((heroByID) => (this.hero = heroByID));
  }
  onSubmit() {
    console.warn(this.heroprofileform.value);

    HEROES.push(this.hero2);
  }
  onDelete(){
    const indexOfObject = HEROES.findIndex((object) => {
      return object;
    });
    console.log(indexOfObject);
    if (indexOfObject !== -1) {
    HEROES.splice(indexOfObject,1);
    }
    console.log(HEROES);
  }
  }
