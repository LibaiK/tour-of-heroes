import { Component, OnInit } from '@angular/core';
import { Season } from 'src/app/_models/season';
import { SeasonService } from 'src/app/_services/season.service';

@Component({
  selector: 'app-season',
  templateUrl: './season.component.html',
  styleUrls: ['./season.component.less']
})
export class SeasonComponent implements OnInit {
  SeasonsArray: Season[] = [];
  constructor(private _SeasonService: SeasonService) {}

  ngOnInit(): void {
    this.getSeasons();
  }
getSeasons() : void{
this._SeasonService.getSeason().subscribe(result=>this.SeasonsArray= result)
}
}
