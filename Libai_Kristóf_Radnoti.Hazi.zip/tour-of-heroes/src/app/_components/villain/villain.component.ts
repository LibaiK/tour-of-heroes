import { Component, OnInit } from '@angular/core';
import { Villain } from 'src/app/_models/Villain';
import { VillainService } from 'src/app/_services/villain.service';

@Component({
  selector: 'app-villain',
  templateUrl: './villain.component.html',
  styleUrls: ['./villain.component.less']
})
export class VillainComponent implements OnInit {


  constructor(private VillainService : VillainService) { }
  villains: Villain [] = [];

  ngOnInit(): void {
    this.getVillians();
  }
getVillians():void{
  this.VillainService.getVillians().subscribe(villains => this.villains = villains)
}
}
