import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Villain } from 'src/app/_models/Villain';
import { MessageService } from 'src/app/_services/message.service';
import { VillainService } from 'src/app/_services/villain.service';
import { Validators } from '@angular/forms';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { VILLAINS } from 'src/app/fake-db_villians';

@Component({
  selector: 'app-villian-detail',
  templateUrl: './villian-detail.component.html',
  styleUrls: ['./villian-detail.component.less']
})
export class VillianDetailComponent implements OnInit {
  villianprofileform = new FormGroup({
    villianname :  new FormControl('',Validators.required),
    villianage :new FormControl('',Validators.required),
    superpower : new FormControl('',Validators.required)
  })
  villian:Villain | undefined;

  constructor(private route: ActivatedRoute,
    private VillianService: VillainService,
    private _messageService: MessageService,
    private fb: FormBuilder) { }

    Villian:Villain = {
      id:10,
      Villainame:"BlackFish",
      age:45,
      superpower:'Laser eater'
    }

  ngOnInit(): void {
    this.getVillainById();

    this._messageService.add(`A ${this.villian?.Villainame} nevű villian betöltve`);
  }
  getVillainById():void{
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.VillianService.getVillian(id).subscribe((VillianById)=>(this.villian = VillianById));
  }
  onSubmit() {
    console.warn(this.villianprofileform.value);
    VILLAINS.push(this.Villian);
      }
      onDelete(){
        const indexOfObject = VILLAINS.findIndex((object) => {
          return object;
        });
        console.log(indexOfObject);

        if (indexOfObject !== -1) {
        VILLAINS.splice(indexOfObject,1);
        }
        console.log(VILLAINS);
      }
}
