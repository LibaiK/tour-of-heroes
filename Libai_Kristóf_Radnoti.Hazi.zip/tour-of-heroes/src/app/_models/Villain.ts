export interface Villain{
  id: number;
  Villainame:string;
  age:number;
  superpower:string;
}
