export interface Hero{
id: number;
name:string;
age:number;
superpower:string;
}
