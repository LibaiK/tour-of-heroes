export interface Season{
  id: number;
  seasoname:string;
}
