import { Injectable } from '@angular/core';
import { Hero } from 'src/app/_models/hero';
import { HEROES } from 'src/app/fake-db';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HeroService {

  constructor() { }
  getHeroes() : Observable<Hero[]>{
    const heroes = of(HEROES);
    return heroes;
  }
  //Melyik idjú herot szeretnél lekérnni
  getHero(id:number):Observable<Hero>{
    const hero = HEROES.find(element=>element.id===id)!;
    return of(hero);
  }
}
