import { Injectable } from '@angular/core';

import { Observable, of } from 'rxjs';

import { Hero } from 'src/app/_models/hero';
import { HEROES } from 'src/app/fake-db';
import { MessageService } from './message.service';

@Injectable({
  providedIn: 'root',
})
export class HeroService {

  constructor(private messageService: MessageService) { }

  getHeroes(): Observable<Hero[]> {
    const heroes = of(HEROES);
    this.messageService.add('A Heroes adatok lekérve');
    return heroes;
  }
   getHero(ID: number): Observable<Hero> {
    const hero = HEROES.find((element) => element.id === ID)!;
    this.messageService.add('A getHero() metódus lefutott');
    return of(hero);
  }
}
