import { Injectable } from '@angular/core';
import { Observable,of } from 'rxjs';
import { SEASONS } from '../fake-db_season';
import { Season } from '../_models/season';

@Injectable({
  providedIn: 'root'
})
export class SeasonService {

  constructor() { }
  getSeason() : Observable<Season[]>{
    const seasons = of(SEASONS);
    return seasons;
  }
}
