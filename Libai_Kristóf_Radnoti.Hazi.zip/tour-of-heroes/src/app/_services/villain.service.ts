import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { VILLAINS } from '../fake-db_villians';
import { Villain } from '../_models/Villain';
import {MessageService} from './message.service';

@Injectable({
  providedIn: 'root'
})
export class VillainService {

  constructor(private MessageService:MessageService) { }

  getVillians():Observable<Villain[]>{
    const villians = of(VILLAINS);
    this.MessageService.add('A Villians adatok lekérve');
    return villians;
  }
  getVillian(ID: number): Observable<Villain> {
    const villian = VILLAINS.find((element) => element.id === ID)!;
    this.MessageService.add('A getHero() metódus lefutott');
    return of(villian);
  }
}


