import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './_components/dashboard/dashboard.component';
import { HeroDetailComponent } from './_components/hero-detail/hero-detail.component';
import { HeroesComponent } from './_components/heroes/heroes.component';
import { VillainComponent } from './_components/villain/villain.component';
import { VillianDetailComponent } from './_components/villian-detail/villian-detail.component';

const routes: Routes = [
  {path: 'heroes', component:HeroesComponent},
  {path: 'dashboard', component:DashboardComponent},
  {path: 'detail/:id', component:HeroDetailComponent},
  {path:'Villains',component:VillainComponent},
  {path:'details/:id',component:VillianDetailComponent}
  // { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
  // {path:'**',redirectTo:'dashboard'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
