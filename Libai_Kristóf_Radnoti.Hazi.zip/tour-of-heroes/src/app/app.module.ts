import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeroesComponent } from './_components/heroes/heroes.component';
import { ChildComponent } from './_components/child/child.component';
import { FormsModule } from '@angular/forms';
import { HeroDetailComponent } from './_components/hero-detail/hero-detail.component';
import { SeasonComponent } from './_components/season/season.component';
import { DashboardComponent } from './_components/dashboard/dashboard.component';
import { MessagesComponent } from './_components/messages/messages.component';
import { VillainComponent } from './_components/villain/villain.component';
import { VillianDetailComponent } from './_components/villian-detail/villian-detail.component';
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    HeroesComponent,
    ChildComponent,
    HeroDetailComponent,
    SeasonComponent,
    DashboardComponent,
    MessagesComponent,
    VillainComponent,
    VillianDetailComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
