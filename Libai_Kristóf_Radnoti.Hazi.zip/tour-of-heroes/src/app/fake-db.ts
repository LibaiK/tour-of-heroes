import { Hero } from "./_models/hero";

export const HEROES:Hero[] = [
    {id:1,name:'Batman',age:25,superpower:'Laser vision'},
    {id:2,name:'Superman',age:78,superpower:'Night Care'},
    {id:3,name:'Catwoman',age:45,superpower:'Superhuman reflexes'},
    {id:4,name:'Darth Vader',age:32,superpower:'Sophisticated senses'},
    {id:5,name:'Obi-wan Kenobi',age:24,superpower:'Invisibility'},
    {id:6,name:'Luke Sky Walker',age:57,superpower:'Invulnerability'},
    {id:7,name:'Han Solo',age:78,superpower:'Superfast'},
    {id:8,name:'Jay',age:27,superpower:'Underwater breathing'},
    {id:9,name:'Silente Bob',age:67,superpower:'Reproduction'},
];

