import { Season } from "./_models/season";

export const SEASONS:Season[] = [
  {id:1,seasoname:'Spring'},
  {id:2,seasoname:'Summer'},
  {id:3,seasoname:'Autumn'},
  {id:4,seasoname:'Winter'},
]
