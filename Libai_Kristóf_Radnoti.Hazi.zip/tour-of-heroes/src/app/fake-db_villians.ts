import { Villain } from "./_models/Villain";

export const VILLAINS:Villain[] = [
  {id:10,Villainame:'Joker',age:53,superpower:'Bananaeater'},
  {id:11,Villainame:'Ironman',age:54,superpower:'grassjumper'},
  {id:12,Villainame:'Dogman',age:43,superpower:'noluck'},
  {id:13,Villainame:'Mastermind',age:24,superpower:'lucker'},
  {id:14,Villainame:'Arcade',age:45,superpower:'Invisibility Hairs'},
  {id:15,Villainame:'Orphan-Maker',age:35,superpower:'Grassjumper'},
  {id:16,Villainame:'Sin-Eater',age:24,superpower:'hahaeater'},
  {id:17,Villainame:'Cybelle',age:27,superpower:'Treejumper with Invisibility'},
  {id:18,Villainame:'Domo',age:56,superpower:'Magic with Air'}
]
